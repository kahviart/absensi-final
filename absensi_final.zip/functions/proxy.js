const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));

const GAS_URL = 'https://script.google.com/macros/s/AKfycbwhr3Huf7JhPaAHiZPD96GwsOMwhWLSAWmSd7nLzCPiP8D9aiKJgx6suH4G57HzdFFDaw/exec';

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 204,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type'
      },
      body: ''
    };
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  try {
    const data = JSON.parse(event.body || '{}');
    const params = new URLSearchParams();
    ['nama', 'kelas', 'jurusan', 'sesi', 'latitude', 'longitude', 'foto'].forEach(key =>
      params.set(key, data[key] || '')
    );

    const resp = await fetch(GAS_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: params.toString()
    });

    const text = await resp.text();
    const ok = resp.ok && text.trim().toLowerCase() === 'success';

    return {
      statusCode: ok ? 200 : 500,
      headers: { 'Access-Control-Allow-Origin': '*', 'Content-Type': 'text/plain' },
      body: ok ? 'success' : text || 'failed'
    };
  } catch (err) {
    return {
      statusCode: 500,
      headers: { 'Access-Control-Allow-Origin': '*', 'Content-Type': 'text/plain' },
      body: 'Error: ' + (err.message || String(err))
    };
  }
};
